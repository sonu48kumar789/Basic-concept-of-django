from django import forms
from .models import *


class InsertStudent(forms.ModelForm):
    class Meta:
        model = Student
        exclude = ('date_of_creation', 'status')


class InsertCourse(forms.ModelForm):
    class Meta:
        model = Course
        fields = '__all__'


