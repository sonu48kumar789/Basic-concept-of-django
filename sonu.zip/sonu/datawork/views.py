from django.shortcuts import render, redirect
from .forms import *
from .models import *
# Create your views here.


def home(r):
    return render(r, 'home.html')

def apply(r):
    form = InsertStudent(r.POST or None, r.FILES or None)
    data = {"insert_form": form}
    if r.method == "POST":
        if form.is_valid():
            form.save()
            return redirect(apply)
        else:
            return render(r, 'apply.html', data)
    return render(r, 'apply.html', data)
